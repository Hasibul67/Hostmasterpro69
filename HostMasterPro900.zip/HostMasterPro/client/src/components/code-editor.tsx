import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Save, Play, Download, Upload, FileText, Eye } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileNode {
  id: string;
  name: string;
  type: "file" | "folder";
  content?: string;
  children?: FileNode[];
}

interface CodeEditorProps {
  file: FileNode | null;
  onSave: (content: string) => void;
  onRun?: () => void;
  language: string;
}

const getFileLanguage = (filename: string): string => {
  const ext = filename.split('.').pop()?.toLowerCase();
  switch (ext) {
    case 'js': return 'javascript';
    case 'ts': return 'typescript';
    case 'py': return 'python';
    case 'php': return 'php';
    case 'html': return 'html';
    case 'css': return 'css';
    case 'json': return 'json';
    case 'md': return 'markdown';
    case 'go': return 'go';
    case 'rs': return 'rust';
    case 'java': return 'java';
    case 'jsx': return 'jsx';
    case 'tsx': return 'tsx';
    default: return 'text';
  }
};

const getLanguageTemplate = (language: string, filename: string): string => {
  const fileType = getFileLanguage(filename);
  
  switch (fileType) {
    case 'javascript':
      return `// ${filename}
const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.json());

// Routes
app.get('/', (req, res) => {
  res.json({ 
    message: 'Hello from your Node.js app!',
    timestamp: new Date().toISOString(),
    status: 'running'
  });
});

app.get('/api/status', (req, res) => {
  res.json({ 
    status: 'online',
    uptime: process.uptime(),
    memory: process.memoryUsage()
  });
});

// Start server
app.listen(port, '0.0.0.0', () => {
  console.log(\`🚀 Server running on port \${port}\`);
  console.log(\`🌐 Access your app at: http://localhost:\${port}\`);
});

// Your code here...
`;
    case 'typescript':
      return `// ${filename}
console.log('Hello from ${filename}!');

// Your TypeScript code here...
`;
    case 'python':
      return `# ${filename}
print(f'Hello from ${filename}!')

# Your Python code here...
`;
    case 'php':
      return `<?php
// ${filename}
echo "Hello from ${filename}!";

// Your PHP code here...
?>`;
    case 'html':
      return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Project</title>
</head>
<body>
    <h1>Hello World!</h1>
    <p>Welcome to your new project!</p>
</body>
</html>`;
    case 'css':
      return `/* ${filename} */
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    margin: 0;
    padding: 20px;
    background-color: #f5f5f5;
}

/* Your styles here... */
`;
    case 'json':
      return `{
  "name": "my-project",
  "version": "1.0.0",
  "description": "My awesome project",
  "main": "index.js",
  "scripts": {
    "start": "node index.js"
  }
}`;
    case 'markdown':
      return `# ${filename.replace('.md', '')}

Welcome to your new project!

## Getting Started

Add your documentation here...
`;
    case 'go':
      return `package main

import "fmt"

func main() {
    fmt.Println("Hello from ${filename}!")
    
    // Your Go code here...
}`;
    default:
      return `// ${filename}
// Your code here...
`;
  }
};

export default function CodeEditor({ file, onSave, onRun, language }: CodeEditorProps) {
  const [content, setContent] = useState("");
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    if (file) {
      const initialContent = file.content || getLanguageTemplate(language, file.name);
      setContent(initialContent);
      setHasChanges(false);
    }
  }, [file, language]);

  const handleContentChange = (newContent: string) => {
    setContent(newContent);
    setHasChanges(newContent !== (file?.content || ""));
  };

  const handleSave = () => {
    onSave(content);
    setHasChanges(false);
  };

  const handleDownload = () => {
    if (!file) return;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!file) {
    return (
      <div className="flex-1 flex items-center justify-center bg-muted/20">
        <div className="text-center text-muted-foreground">
          <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p className="text-lg font-medium mb-2">No file selected</p>
          <p className="text-sm">Select a file from the explorer to start editing</p>
        </div>
      </div>
    );
  }

  if (file.type === "folder") {
    return (
      <div className="flex-1 flex items-center justify-center bg-muted/20">
        <div className="text-center text-muted-foreground">
          <Eye className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p className="text-lg font-medium mb-2">Folder selected</p>
          <p className="text-sm">Select a file to view its contents</p>
        </div>
      </div>
    );
  }

  const fileLanguage = getFileLanguage(file.name);

  return (
    <div className="flex flex-col h-full">
      {/* Editor Header */}
      <div className="flex items-center justify-between p-3 border-b border-border bg-muted/30">
        <div className="flex items-center gap-3">
          <span className="font-medium text-sm">{file.name}</span>
          <Badge variant="secondary" className="text-xs">
            {fileLanguage}
          </Badge>
          {hasChanges && (
            <Badge variant="outline" className="text-xs text-amber-600 border-amber-600">
              Unsaved
            </Badge>
          )}
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleDownload}
            className="h-7 px-2"
          >
            <Download className="h-3 w-3 mr-1" />
            Download
          </Button>
          
          {onRun && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onRun}
              className="h-7 px-2 text-green-600 hover:text-green-700"
            >
              <Play className="h-3 w-3 mr-1" />
              Run
            </Button>
          )}

          <Button
            variant="default"
            size="sm"
            onClick={handleSave}
            disabled={!hasChanges}
            className="h-7 px-3"
          >
            <Save className="h-3 w-3 mr-1" />
            Save
          </Button>
        </div>
      </div>

      {/* Editor Content */}
      <div className="flex-1 relative">
        <Textarea
          value={content}
          onChange={(e) => handleContentChange(e.target.value)}
          className={cn(
            "h-full resize-none border-0 rounded-none focus-visible:ring-0",
            "font-mono text-sm leading-relaxed",
            "bg-background"
          )}
          placeholder="Start typing your code..."
          spellCheck={false}
        />
      </div>
    </div>
  );
}