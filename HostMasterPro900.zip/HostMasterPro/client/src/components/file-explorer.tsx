import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuTrigger } from "@/components/ui/context-menu";
import { Folder, File, Plus, FolderPlus, Trash2, Edit, Download, Upload } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileNode {
  id: string;
  name: string;
  type: "file" | "folder";
  content?: string;
  children?: FileNode[];
  isOpen?: boolean;
}

interface FileExplorerProps {
  files: FileNode[];
  onFileSelect: (file: FileNode) => void;
  onFileCreate: (name: string, type: "file" | "folder", parentId?: string) => void;
  onFileDelete: (id: string) => void;
  onFileRename: (id: string, newName: string) => void;
  selectedFileId?: string;
}

export default function FileExplorer({
  files,
  onFileSelect,
  onFileCreate,
  onFileDelete,
  onFileRename,
  selectedFileId
}: FileExplorerProps) {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [createType, setCreateType] = useState<"file" | "folder">("file");
  const [createParentId, setCreateParentId] = useState<string | undefined>();
  const [newItemName, setNewItemName] = useState("");
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set());

  const toggleFolder = (folderId: string) => {
    const newExpanded = new Set(expandedFolders);
    if (newExpanded.has(folderId)) {
      newExpanded.delete(folderId);
    } else {
      newExpanded.add(folderId);
    }
    setExpandedFolders(newExpanded);
  };

  const handleCreate = () => {
    if (newItemName.trim()) {
      onFileCreate(newItemName.trim(), createType, createParentId);
      setNewItemName("");
      setShowCreateDialog(false);
      setCreateParentId(undefined);
    }
  };

  const renderFileNode = (node: FileNode, depth = 0) => {
    const isSelected = selectedFileId === node.id;
    const isExpanded = expandedFolders.has(node.id);

    return (
      <div key={node.id}>
        <ContextMenu>
          <ContextMenuTrigger>
            <div
              className={cn(
                "flex items-center gap-2 px-2 py-1 cursor-pointer hover:bg-accent/50 rounded-sm text-sm",
                isSelected && "bg-primary/10 text-primary",
                "transition-colors"
              )}
              style={{ paddingLeft: `${depth * 16 + 8}px` }}
              onClick={() => {
                if (node.type === "folder") {
                  toggleFolder(node.id);
                } else {
                  onFileSelect(node);
                }
              }}
            >
              {node.type === "folder" ? (
                <Folder 
                  className={cn(
                    "h-4 w-4 flex-shrink-0",
                    isExpanded ? "text-blue-500" : "text-gray-500"
                  )} 
                />
              ) : (
                <File className="h-4 w-4 flex-shrink-0 text-gray-600" />
              )}
              <span className="truncate">{node.name}</span>
            </div>
          </ContextMenuTrigger>
          <ContextMenuContent>
            {node.type === "folder" && (
              <>
                <ContextMenuItem
                  onClick={() => {
                    setCreateType("file");
                    setCreateParentId(node.id);
                    setShowCreateDialog(true);
                  }}
                >
                  <File className="h-4 w-4 mr-2" />
                  New File
                </ContextMenuItem>
                <ContextMenuItem
                  onClick={() => {
                    setCreateType("folder");
                    setCreateParentId(node.id);
                    setShowCreateDialog(true);
                  }}
                >
                  <FolderPlus className="h-4 w-4 mr-2" />
                  New Folder
                </ContextMenuItem>
              </>
            )}
            <ContextMenuItem
              onClick={() => {
                const newName = prompt("Rename to:", node.name);
                if (newName && newName !== node.name) {
                  onFileRename(node.id, newName);
                }
              }}
            >
              <Edit className="h-4 w-4 mr-2" />
              Rename
            </ContextMenuItem>
            <ContextMenuItem
              onClick={() => {
                if (confirm(`Delete ${node.name}?`)) {
                  onFileDelete(node.id);
                }
              }}
              className="text-red-600"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </ContextMenuItem>
          </ContextMenuContent>
        </ContextMenu>

        {node.type === "folder" && isExpanded && node.children && (
          <div>
            {node.children.map((child) => renderFileNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between p-3 border-b border-border">
        <h3 className="font-medium text-sm">Files</h3>
        <div className="flex gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={() => {
              setCreateType("file");
              setCreateParentId(undefined);
              setShowCreateDialog(true);
            }}
          >
            <Plus className="h-3 w-3" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={() => {
              setCreateType("folder");
              setCreateParentId(undefined);
              setShowCreateDialog(true);
            }}
          >
            <FolderPlus className="h-3 w-3" />
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-2">
        {files.length === 0 ? (
          <div className="text-center text-muted-foreground text-sm py-8">
            No files yet. Create your first file to get started.
          </div>
        ) : (
          files.map((file) => renderFileNode(file))
        )}
      </div>

      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              Create New {createType === "file" ? "File" : "Folder"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              placeholder={`Enter ${createType} name...`}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleCreate();
                }
              }}
              autoFocus
            />
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowCreateDialog(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button onClick={handleCreate} className="flex-1">
                Create
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}