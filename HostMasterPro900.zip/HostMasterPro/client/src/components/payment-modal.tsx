import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CreditCard, ExternalLink } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPlan: "basic" | "pro" | null;
}

export default function PaymentModal({ isOpen, onClose, selectedPlan }: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState<string>("");
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const submitPaymentMutation = useMutation({
    mutationFn: async (data: { planType: string; paymentMethod: string; amount: number; screenshot?: File }) => {
      const formData = new FormData();
      formData.append("userId", "1"); // Mock user ID
      formData.append("planType", data.planType);
      formData.append("paymentMethod", data.paymentMethod);
      formData.append("amount", data.amount.toString());
      if (data.screenshot) {
        formData.append("screenshot", data.screenshot);
      }

      const response = await fetch("/api/payments", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error("Failed to submit payment");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Payment Submitted",
        description: "Your payment has been submitted for verification. You will be contacted on Telegram within 1-2 hours.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlan || !paymentMethod) return;

    const amount = selectedPlan === "basic" ? 300 : 500; // Convert to cents
    submitPaymentMutation.mutate({
      planType: selectedPlan,
      paymentMethod,
      amount,
      screenshot: screenshot || undefined,
    });
  };

  const planDetails = {
    basic: { name: "Basic Plan", price: "$3", bots: "1 bot" },
    pro: { name: "Pro Plan", price: "$5", bots: "4 bots" },
  };

  const paymentMethods = [
    { value: "binance", label: "Binance Pay", account: "510311493", icon: "₿" },
    { value: "bkash", label: "Bkash", account: "01715842614", icon: "📱" },
    { value: "nagad", label: "Nagad", account: "01715842614", icon: "💳" },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Complete Payment
          </DialogTitle>
        </DialogHeader>

        {selectedPlan && (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="p-4 bg-blue-50 rounded-lg">
              <div className="flex justify-between items-center">
                <span className="font-medium">Selected Plan:</span>
                <span className="text-primary font-semibold">
                  {planDetails[selectedPlan].name} - {planDetails[selectedPlan].price}
                </span>
              </div>
              <p className="text-sm text-gray-600 mt-1">
                Host up to {planDetails[selectedPlan].bots}
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="paymentMethod">Payment Method</Label>
                <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentMethods.map((method) => (
                      <SelectItem key={method.value} value={method.value}>
                        <div className="flex items-center gap-2">
                          <span>{method.icon}</span>
                          <span>{method.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {paymentMethod && (
                <div className="p-3 bg-gray-50 rounded-lg">
                  <Label className="text-sm font-medium">Payment Details:</Label>
                  <div className="mt-1 p-2 bg-white rounded border font-mono text-sm">
                    {paymentMethods.find(m => m.value === paymentMethod)?.account}
                  </div>
                </div>
              )}

              <div>
                <Label htmlFor="screenshot">Payment Screenshot (Optional)</Label>
                <Input
                  id="screenshot"
                  type="file"
                  accept="image/*"
                  onChange={(e) => setScreenshot(e.target.files?.[0] || null)}
                />
              </div>
            </div>

            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium mb-2">Payment Instructions:</h4>
              <ol className="list-decimal list-inside space-y-1 text-sm text-gray-700">
                <li>Make payment using the details above</li>
                <li>Take a screenshot of confirmation</li>
                <li>Upload screenshot or send to @Rafi_00019</li>
                <li>Wait for verification (1-2 hours)</li>
              </ol>
            </div>

            <div className="flex gap-3">
              <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={!paymentMethod || submitPaymentMutation.isPending}
                className="flex-1"
              >
                {submitPaymentMutation.isPending ? "Submitting..." : "Submit Payment"}
              </Button>
            </div>

            <div className="text-center">
              <Button variant="link" asChild>
                <a
                  href="https://t.me/Rafi_00019"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1"
                >
                  Contact @Rafi_00019 <ExternalLink className="h-3 w-3" />
                </a>
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
