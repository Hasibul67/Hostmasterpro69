import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Users, Server, Clock, DollarSign, Eye, CheckCircle, XCircle, Settings } from "lucide-react";
import Navbar from "@/components/navbar";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Payment, User } from "@shared/schema";

interface AdminStats {
  totalUsers: number;
  activeProjects: number;
  pendingPayments: number;
  revenue: number;
}

export default function Admin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
  });

  const { data: pendingPayments } = useQuery<Payment[]>({
    queryKey: ["/api/payments", { status: "pending" }],
    queryFn: async () => {
      const response = await fetch("/api/payments?status=pending");
      return response.json();
    },
  });

  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const approvePaymentMutation = useMutation({
    mutationFn: (paymentId: number) =>
      apiRequest("PATCH", `/api/payments/${paymentId}`, { status: "approved" }),
    onSuccess: () => {
      toast({
        title: "Payment Approved",
        description: "The payment has been approved and the user's plan has been activated.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const rejectPaymentMutation = useMutation({
    mutationFn: (paymentId: number) =>
      apiRequest("PATCH", `/api/payments/${paymentId}`, { status: "rejected" }),
    onSuccess: () => {
      toast({
        title: "Payment Rejected",
        description: "The payment has been rejected.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleViewScreenshot = (paymentId: number) => {
    // In a real app, this would open the screenshot in a modal or new tab
    toast({
      title: "Screenshot View",
      description: "Screenshot viewing functionality would open the image here.",
    });
  };

  const statCards = [
    {
      title: "Total Users",
      value: stats?.totalUsers || 0,
      icon: Users,
      iconBg: "bg-blue-50",
      iconColor: "text-primary",
    },
    {
      title: "Active Projects", 
      value: stats?.activeProjects || 0,
      icon: Server,
      iconBg: "bg-green-50",
      iconColor: "text-secondary",
    },
    {
      title: "Pending Payments",
      value: stats?.pendingPayments || 0,
      icon: Clock,
      iconBg: "bg-yellow-50",
      iconColor: "text-accent",
    },
    {
      title: "Monthly Revenue",
      value: `$${stats?.revenue || 0}`,
      icon: DollarSign,
      iconBg: "bg-purple-50",
      iconColor: "text-purple-600",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="shadow-lg mb-12">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl">Admin Panel</CardTitle>
              <div className="flex space-x-4">
                <Button className="bg-primary hover:bg-blue-600">
                  <Users className="mr-2 h-4 w-4" />
                  Manage Users
                </Button>
                <Button className="bg-secondary hover:bg-green-600">
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Payment Verification
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {/* Stats Overview */}
            <div className="grid md:grid-cols-4 gap-6 mb-8">
              {statCards.map((stat) => {
                const Icon = stat.icon;
                return (
                  <div key={stat.title} className={`p-6 rounded-lg ${stat.iconBg.replace('50', '50')}`}>
                    <div className="flex items-center">
                      <div className={`w-12 h-12 ${stat.iconBg.replace('50', '100')} rounded-lg flex items-center justify-center mr-4`}>
                        <Icon className={`h-6 w-6 ${stat.iconColor}`} />
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">{stat.title}</p>
                        <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Pending Payment Verifications */}
            <div className="mb-8">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Pending Payment Verifications</h4>
              <div className="bg-white rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead>User</TableHead>
                      <TableHead>Plan</TableHead>
                      <TableHead>Payment Method</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Screenshot</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingPayments?.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                          No pending payments
                        </TableCell>
                      </TableRow>
                    ) : (
                      pendingPayments?.map((payment) => (
                        <TableRow key={payment.id}>
                          <TableCell>
                            <div className="flex items-center">
                              <Avatar className="mr-3">
                                <AvatarFallback>U{payment.userId}</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="text-sm font-medium text-gray-900">User {payment.userId}</div>
                                <div className="text-sm text-gray-500">@user{payment.userId}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={
                                payment.planType === "pro"
                                  ? "bg-blue-100 text-blue-800"
                                  : "bg-green-100 text-green-800"
                              }
                            >
                              {payment.planType === "pro" ? "Pro Plan" : "Basic Plan"}
                            </Badge>
                          </TableCell>
                          <TableCell className="capitalize">{payment.paymentMethod}</TableCell>
                          <TableCell>${(payment.amount / 100).toFixed(2)}</TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleViewScreenshot(payment.id)}
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                className="bg-secondary hover:bg-green-600 text-white"
                                onClick={() => approvePaymentMutation.mutate(payment.id)}
                                disabled={approvePaymentMutation.isPending}
                              >
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Approve
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => rejectPaymentMutation.mutate(payment.id)}
                                disabled={rejectPaymentMutation.isPending}
                              >
                                <XCircle className="h-3 w-3 mr-1" />
                                Reject
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>

            {/* User Management */}
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Recent Users</h4>
              <div className="space-y-4">
                {users?.slice(0, 5).map((user) => (
                  <div
                    key={user.id}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center">
                      <Avatar className="mr-4">
                        <AvatarFallback>
                          {user.username.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium text-gray-900">{user.username}</div>
                        <div className="text-sm text-gray-500">{user.email}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <span className="text-sm text-gray-600 capitalize">
                        {user.planType === "none" ? "No Plan" : `${user.planType} Plan`}
                      </span>
                      <Badge
                        className={
                          user.planType !== "none"
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-800"
                        }
                      >
                        {user.planType !== "none" ? "Active" : "Inactive"}
                      </Badge>
                      <Button variant="ghost" size="icon">
                        <Settings className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
