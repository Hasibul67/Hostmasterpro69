import type { Project } from "@shared/schema";

declare global {
  interface Window {
    openProjectWorkspace?: (project: Project) => void;
  }
}

export {};