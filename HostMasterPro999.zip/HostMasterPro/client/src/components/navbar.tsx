import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Server, Bell, User } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Navbar() {
  const [location] = useLocation();
  
  const isActive = (path: string) => location === path;
  
  return (
    <nav className="bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <Server className="h-8 w-8 text-primary mr-2" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                BotHost Pro
              </h1>
            </Link>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <Link href="/">
                <Button
                  variant={isActive("/") ? "default" : "ghost"}
                  className={isActive("/") ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"}
                >
                  Dashboard
                </Button>
              </Link>
              <Link href="/payment">
                <Button
                  variant={isActive("/payment") ? "default" : "ghost"}
                  className={isActive("/payment") ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"}
                >
                  Plans
                </Button>
              </Link>
              <Link href="/admin">
                <Button
                  variant={isActive("/admin") ? "default" : "ghost"}
                  className={isActive("/admin") ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"}
                >
                  Admin
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <ThemeToggle />
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <div className="h-8 w-8 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-white" />
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
