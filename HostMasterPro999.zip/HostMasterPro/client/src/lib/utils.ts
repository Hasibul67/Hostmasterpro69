import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

export function formatUptime(uptime: string): string {
  return uptime || "0%";
}

export function getPlanLimits(planType: string): { maxProjects: number; price: number } {
  switch (planType) {
    case "basic":
      return { maxProjects: 1, price: 3 };
    case "pro":
      return { maxProjects: 4, price: 5 };
    default:
      return { maxProjects: 0, price: 0 };
  }
}
