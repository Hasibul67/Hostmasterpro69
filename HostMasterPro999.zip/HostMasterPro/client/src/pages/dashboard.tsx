import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Code, ExternalLink, GitBranch, Plus, Settings, BarChart3, Headphones, Zap, Terminal, Activity, Globe, Play, Eye, Server, Edit } from "lucide-react";
import Navbar from "@/components/navbar";
import ProjectCreationModal from "@/components/bot-creation-modal";
import ProjectWorkspace from "@/components/project-workspace";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { getPlanLimits } from "@/lib/utils";
import type { Project, User } from "@shared/schema";

export default function Dashboard() {
  const [showProjectModal, setShowProjectModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [showWorkspace, setShowWorkspace] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mock current user - in real app this would come from auth
  const currentUser: User = {
    id: 1,
    username: "admin",
    email: "admin@bothost.pro",
    telegramUsername: "Rafi_00019",
    planType: "pro",
    isAdmin: true,
  };

  const { data: projects, isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects", { userId: currentUser.id }],
    queryFn: async () => {
      const response = await fetch(`/api/projects?userId=${currentUser.id}`);
      return response.json();
    },
  });

  // Global function to open workspace from project creation
  useEffect(() => {
    window.openProjectWorkspace = (project: Project) => {
      setSelectedProject(project);
      setShowWorkspace(true);
    };
  }, []);

  // Auto-open the TelegramBot project workspace
  useEffect(() => {
    if (projects && projects.length > 0 && !showWorkspace && !selectedProject) {
      const telegramBot = projects.find(p => p.name === "TelegramBot");
      if (telegramBot) {
        setTimeout(() => {
          setSelectedProject(telegramBot);
          setShowWorkspace(true);
        }, 500);
      }
    }
  }, [projects, showWorkspace, selectedProject]);

  const deployProjectMutation = useMutation({
    mutationFn: (projectId: number) =>
      apiRequest("POST", `/api/projects/${projectId}/deploy`),
    onSuccess: () => {
      toast({
        title: "Deployment Started",
        description: "Your project is being deployed. This may take a few minutes.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
    },
    onError: (error: any) => {
      toast({
        title: "Deployment Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const currentPlan = getPlanLimits(currentUser.planType);
  const usedSlots = projects?.length || 0;
  const availableSlots = Math.max(0, currentPlan.maxProjects - usedSlots);

  const getLanguageIcon = (language: string) => {
    switch (language) {
      case "nodejs": return "🟢";
      case "python": return "🐍";
      case "php": return "🐘";
      case "html": return "🌐";
      case "react": return "⚛️";
      case "go": return "🐹";
      default: return "📦";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-medium mb-6">
            <Activity className="h-4 w-4" />
            <span>All systems operational</span>
          </div>
          <h2 className="text-4xl font-bold bg-gradient-to-r from-foreground to-muted-foreground bg-clip-text text-transparent mb-4">
            Deploy Any Project, Any Language
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Host websites, APIs, bots, and applications in Node.js, Python, PHP, Go, and more. No configuration needed.
          </p>
        </div>

        {/* Dashboard Content */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {/* Project Management */}
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold">My Projects</h3>
              <Button 
                onClick={() => setShowProjectModal(true)}
                className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90"
              >
                <Plus className="h-4 w-4 mr-2" />
                New Project
              </Button>
            </div>
            <div className="space-y-4">
              {projectsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-6">
                        <div className="h-20 bg-muted/20 rounded"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <>
                  {projects?.map((project) => (
                    <Card key={project.id} className="border-0 bg-card/50 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-600 rounded-xl flex items-center justify-center mr-4 shadow-lg">
                              <span className="text-xl">{getLanguageIcon(project.language)}</span>
                            </div>
                            <div>
                              <h4 className="font-semibold">{project.name}</h4>
                              <p className="text-sm text-muted-foreground capitalize">
                                {project.language}{project.framework ? ` • ${project.framework}` : ""}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge
                              variant={project.status === "online" ? "default" : project.status === "building" ? "secondary" : "outline"}
                              className={
                                project.status === "online"
                                  ? "bg-green-500/20 text-green-700 border-green-500/30 dark:text-green-400"
                                  : project.status === "building"
                                  ? "bg-yellow-500/20 text-yellow-700 border-yellow-500/30 dark:text-yellow-400"
                                  : "bg-gray-500/20 text-gray-700 border-gray-500/30 dark:text-gray-400"
                              }
                            >
                              <div
                                className={`w-2 h-2 rounded-full mr-2 ${
                                  project.status === "online" ? "bg-green-500 animate-pulse" : 
                                  project.status === "building" ? "bg-yellow-500 animate-pulse" : "bg-gray-400"
                                }`}
                              />
                              {project.status === "online" ? "Live" : 
                               project.status === "building" ? "Building" : "Offline"}
                            </Badge>
                            {project.status === "online" && project.deploymentUrl && (
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="hover:bg-primary/10"
                                onClick={() => window.open(project.deploymentUrl!, '_blank')}
                              >
                                <ExternalLink className="h-4 w-4" />
                              </Button>
                            )}
                            {project.status === "offline" && (
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="hover:bg-primary/10"
                                onClick={() => deployProjectMutation.mutate(project.id)}
                                disabled={deployProjectMutation.isPending}
                              >
                                <Play className="h-4 w-4" />
                              </Button>
                            )}
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="hover:bg-primary/10"
                              onClick={() => {
                                setSelectedProject(project);
                                setShowWorkspace(true);
                              }}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="hover:bg-primary/10">
                              <Settings className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="mt-4 flex items-center text-sm text-muted-foreground">
                          {project.deploymentUrl && (
                            <>
                              <Globe className="w-4 h-4 mr-2" />
                              <span className="truncate max-w-[200px]">{project.deploymentUrl}</span>
                              <span className="mx-4">•</span>
                            </>
                          )}
                          {project.repositoryUrl && (
                            <>
                              <GitBranch className="w-4 h-4 mr-2" />
                              <span>Git connected</span>
                              <span className="mx-4">•</span>
                            </>
                          )}
                          <Eye className="w-4 h-4 mr-2" />
                          <span>{project.isPublic ? "Public" : "Private"}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}

                  {/* Empty Slots */}
                  {Array.from({ length: availableSlots }, (_, i) => (
                    <Card
                      key={`empty-${i}`}
                      className="border-2 border-dashed border-border/50 hover:border-primary/50 transition-all duration-300 cursor-pointer"
                      onClick={() => setShowProjectModal(true)}
                    >
                      <CardContent className="p-6">
                        <div className="text-center">
                          <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4 border-2 border-dashed border-primary/30">
                            <Plus className="h-6 w-6 text-primary" />
                          </div>
                          <h4 className="font-medium text-muted-foreground mb-2">Available Slot</h4>
                          <Button
                            variant="default"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              setShowProjectModal(true);
                            }}
                            className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90"
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Create Project
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Current Plan */}
            <Card className="bg-gradient-to-br from-primary/10 to-secondary/10 border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  Current Plan
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-2">
                    {currentUser.planType === "basic" ? "Basic Plan" :
                     currentUser.planType === "pro" ? "Pro Plan" : "No Plan"}
                  </div>
                  <p className="text-muted-foreground mb-4">{currentPlan.maxProjects} Project Slots</p>
                  <div className="w-full bg-muted/30 rounded-full h-3 mb-4">
                    <div
                      className="bg-gradient-to-r from-primary to-secondary h-3 rounded-full transition-all duration-500"
                      style={{ width: `${currentPlan.maxProjects > 0 ? (usedSlots / currentPlan.maxProjects) * 100 : 0}%` }}
                    />
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    {usedSlots} of {currentPlan.maxProjects} slots used
                  </p>
                  <Button className="w-full bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90">
                    <Zap className="w-4 h-4 mr-2" />
                    Upgrade Plan
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button
                    variant="ghost"
                    className="w-full justify-start p-3 h-auto hover:bg-primary/10"
                    onClick={() => setShowProjectModal(true)}
                    disabled={usedSlots >= currentPlan.maxProjects}
                  >
                    <Plus className="text-primary mr-3 h-5 w-5" />
                    New Project
                  </Button>
                  <Button variant="ghost" className="w-full justify-start p-3 h-auto hover:bg-primary/10">
                    <BarChart3 className="text-primary mr-3 h-5 w-5" />
                    View Analytics
                  </Button>
                  <Button variant="ghost" className="w-full justify-start p-3 h-auto hover:bg-primary/10">
                    <Settings className="text-primary mr-3 h-5 w-5" />
                    Settings
                  </Button>
                  <Button variant="ghost" className="w-full justify-start p-3 h-auto hover:bg-primary/10">
                    <Headphones className="text-primary mr-3 h-5 w-5" />
                    Support
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <ProjectCreationModal
        isOpen={showProjectModal}
        onClose={() => setShowProjectModal(false)}
        userId={currentUser.id}
      />

      {selectedProject && (
        <ProjectWorkspace
          project={selectedProject}
          isOpen={showWorkspace}
          onClose={() => {
            setShowWorkspace(false);
            setSelectedProject(null);
          }}
        />
      )}

      {/* Footer */}
      <footer className="bg-card border-t py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <Server className="mr-2 h-6 w-6" />
                BotHost Pro
              </h3>
              <p className="text-muted-foreground">
                Deploy any application in seconds. Supporting Node.js, Python, PHP, Go, React, and more.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Web Hosting</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">API Hosting</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Bot Hosting</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Database Support</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Documentation</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">FAQ</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Contact</a></li>
                <li><a href="https://t.me/Rafi_00019" className="hover:text-foreground transition-colors">Telegram</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="space-y-2 text-muted-foreground">
                <p>📱 @Rafi_00019</p>
                <p>✉️ support@bothost.pro</p>
                <p>🕐 24/7 Support</p>
              </div>
            </div>
          </div>
          <div className="border-t border-border/40 mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2025 BotHost Pro. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
