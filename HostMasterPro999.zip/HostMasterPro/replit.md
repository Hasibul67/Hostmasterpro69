# BotHost Pro - Universal Application Hosting Platform

## Overview

BotHost Pro is a comprehensive multi-language application hosting platform built with a modern full-stack architecture. The application allows users to deploy, manage, and monitor websites, APIs, bots, and applications in multiple programming languages including Node.js, Python, PHP, Go, React, and static HTML. It features a React frontend with shadcn/ui components, an Express backend, and PostgreSQL database with Drizzle ORM.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for REST API
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **File Uploads**: Multer for handling payment screenshots
- **Session Management**: Built-in session handling for user authentication
- **Development**: TSX for TypeScript execution in development

### Database Design
- **Primary Database**: PostgreSQL (configured for Neon serverless)
- **Schema Management**: Drizzle Kit for migrations
- **Tables**:
  - `users`: User accounts with plan types and admin flags
  - `projects`: Multi-language project configurations with deployment details
  - `payments`: Payment processing with screenshot uploads

## Key Components

### Authentication System
- Simple email-based authentication (no passwords for MVP)
- Admin role-based access control
- Session-based user management

### Project Management
- CRUD operations for multi-language projects
- Support for Node.js, Python, PHP, Go, React, static HTML
- Framework selection (Express, FastAPI, Laravel, etc.)
- Project status monitoring (online/offline/building/error)
- Git repository integration
- Plan-based project limits (Basic: 1 project, Pro: 4 projects)

### Integrated Development Environment (IDE)
- File explorer with create, delete, rename operations
- Syntax-aware code editor with language templates
- Real-time file editing and saving
- Integrated terminal with console output
- Project preview with live iframe rendering
- Language-specific starter templates and boilerplate code

### Payment Processing
- Manual payment verification system
- Support for multiple payment methods (Binance, bKash, Nagad)
- Screenshot upload for payment proof
- Admin approval workflow

### Admin Dashboard
- User management and statistics
- Payment approval/rejection system
- System-wide metrics and monitoring
- Revenue tracking

## Data Flow

1. **User Registration**: Users register with email and create accounts
2. **Project Creation**: Users create projects in various languages within their plan limits
3. **Payment Flow**: Users select plans, submit payment screenshots, admin approves
4. **Project Deployment**: Approved users can deploy and manage their applications
5. **Monitoring**: System tracks project uptime, deployment status, and resource usage

## External Dependencies

### Core Dependencies
- **Database**: Neon PostgreSQL serverless database
- **UI Components**: Radix UI primitives for accessible components
- **Validation**: Zod for runtime type validation
- **Date Handling**: date-fns for date manipulation
- **Icons**: Lucide React for consistent iconography

### Development Dependencies
- **Build Tools**: Vite, esbuild for production builds
- **Type Checking**: TypeScript with strict configuration
- **Styling**: PostCSS with Tailwind CSS

## Deployment Strategy

### Development
- **Environment**: Replit with Node.js 20 runtime
- **Database**: PostgreSQL 16 module
- **Hot Reload**: Vite HMR for frontend, TSX for backend
- **Port Configuration**: Backend on 5000, proxied to port 80

### Production
- **Build Process**: Vite builds frontend, esbuild bundles backend
- **Deployment Target**: Replit Autoscale
- **File Structure**: Built files served from `dist/` directory
- **Static Assets**: Frontend served from `dist/public/`

### Environment Configuration
- **DATABASE_URL**: Required for Drizzle ORM connection
- **NODE_ENV**: Controls development vs production behavior
- **File Uploads**: Stored in `uploads/` directory

## Changelog
```
Changelog:
- June 20, 2025. Initial setup with bot hosting
- June 20, 2025. Evolved to universal hosting platform supporting multiple languages (Node.js, Python, PHP, Go, React, HTML)
- June 20, 2025. Added dark mode with theme toggle and enhanced UI
- June 20, 2025. Implemented project creation modal with language templates and framework selection
- June 20, 2025. Added full IDE workspace with file explorer, code editor, and terminal - users can create, edit, and manage files like Replit
- June 20, 2025. Integrated actual Telegram bot with token 7874841404:AAFZpvo2-iHPubtT43WcxMLNO2cIlN6nxEY and admin ID 7476183212
- June 20, 2025. Added bot UI/preview panel with live chat interface, admin controls, and real-time testing
- June 20, 2025. Created live TelegramBot project with complete bot functionality and workspace auto-open
- June 20, 2025. Successfully deployed live Telegram bot (@Tg_oieieoorir_bot) with token 7874841404:AAFZpvo2-iHPubtT43WcxMLNO2cIlN6nxEY responding to commands
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```